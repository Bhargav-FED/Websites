import React from "react";
import ReactDOM from "react-dom/client";
import AccumentaWebsite from "./AccumentaWebsite";
import "./index.css";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <AccumentaWebsite />
  </React.StrictMode>
);
